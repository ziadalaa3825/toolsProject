package EJBs;
import java.io.Serializable;
import java.util.Set;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Local
@Stateless
@Entity
@Table(name = "USER")
public class User implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Userid")
	int id;
	
	@Column(name="username")
	private String username;
	
	@Column(name="password")
	private String password;
	
	@Column(name="full_name")
	private String full_name;
	
	@Column(name = "role")
	private String role;
	
	@OneToMany(mappedBy = "user",fetch=FetchType.EAGER)
	private Set<Notification> notifications;
	
	
	@ManyToMany
	@JoinTable(
			name="UsersAndTrips",
			joinColumns=@JoinColumn(name="UserID"),
			inverseJoinColumns=@JoinColumn(name ="TripId")
			
		)
	private Set<Trip> trips;
	
	public  User() {
		super();
	}
	public void setId(int i) {
		id = i;
	}
	public int getId() {
		return id;
	}
	public void SetName(String name) {
		username = name;
	}
	public String getName() {
		return username;
	}
	public void SetPassword(String pass) {
		password = pass;
	}
	public String getPassword() {
		return password;
	}
	public void SetRole(String rol) {
		role = rol;
	}
	public String getRole() {
		return role;
	}
	public void SetfullName(String name) {
		full_name = name;
	}
	public String getfullName() {
		return full_name;
	}
}
