package EJBs;

import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2022-06-02T19:36:02.664+0200")
@StaticMetamodel(Trip.class)
public class Trip_ {
	public static volatile SingularAttribute<Trip, String> from_station;
	public static volatile SingularAttribute<Trip, String> to_station;
	public static volatile SingularAttribute<Trip, Integer> available_seats;
	public static volatile SingularAttribute<Trip, String> departure_time;
	public static volatile SingularAttribute<Trip, String> arrival_time;
	public static volatile SingularAttribute<Trip, Integer> id;
	public static volatile SetAttribute<Trip, User> users;
}
