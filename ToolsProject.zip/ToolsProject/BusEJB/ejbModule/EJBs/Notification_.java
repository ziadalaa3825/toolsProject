package EJBs;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2022-06-02T18:55:50.794+0200")
@StaticMetamodel(Notification.class)
public class Notification_ {
	public static volatile SingularAttribute<Notification, String> message;
	public static volatile SingularAttribute<Notification, String> notification_datetime;
	public static volatile SingularAttribute<Notification, Integer> id;
	public static volatile SingularAttribute<Notification, User> user;
}
