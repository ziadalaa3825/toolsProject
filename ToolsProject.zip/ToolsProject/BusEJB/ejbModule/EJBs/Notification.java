package EJBs;

import java.io.Serializable;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Local
@Stateless
@Entity
@Table(name="Notification")
public class Notification implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="NotificationId")
	int id;
	
	@Column(name="Message")
	private String message;
	
	@Column(name="Notification_datetime")
	private String notification_datetime;
	
	@ManyToOne
	@JoinColumn(name = "UserID")
	private User user;
	public Notification() {
		super();
	}
	public void setId(int i) {
		id = i;
	}
	public int getId() {
		return id;
	}
	
	public void SetMessage(String m) {
		message = m;
	}
	public String getMessage() {
		return message;
	}
	public void Setnotification_datetime(String ndt) {
		notification_datetime=ndt;
	}
	public String getnotification_datetime() {
		return notification_datetime;
	}
	

}
