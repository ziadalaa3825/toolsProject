package EJBs;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2022-06-02T18:40:38.954+0200")
@StaticMetamodel(Station.class)
public class Station_ {
	public static volatile SingularAttribute<Station, String> StationName;
	public static volatile SingularAttribute<Station, String> longitude;
	public static volatile SingularAttribute<Station, String> latitude;
	public static volatile SingularAttribute<Station, Integer> id;
}
