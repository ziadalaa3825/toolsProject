package EJBs;

import java.io.Serializable;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Local
@Stateless
@Entity
@Table(name="Station")
public class Station implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="StationId")
	private int id;
	@Column(name="name")
	private String StationName;
	
	@Column(name="longitude")
	private String longitude;
	
	@Column(name="latitude")
	private String latitude;
	
	public Station() {
		super();
	}
	public void setId(int i) {
		id = i;
	}
	public int getId() {
		return id;
	}
	public void SetName(String name) {
		StationName= name;
	}
	public String getName() {
		return StationName;
	}
	public void SetLongitude(String lonng) {
		longitude = lonng;
	}
	public String getLongitude() {
		return longitude;
	}
	public void SetLatitude(String lat) {
		latitude = lat;
	}
	public String getLatitude() {
		return latitude;
	}
}
