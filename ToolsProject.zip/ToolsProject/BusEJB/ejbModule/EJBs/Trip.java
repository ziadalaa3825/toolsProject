package EJBs;
import java.io.Serializable;
import java.util.Set;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Local
@Stateless
@Entity
@Table(name="Trip")
public class Trip implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="TripId")
	private int id;
	@Column(name="from_station")
	private String from_station;
	
	@Column(name="to_station")
	private String to_station;
    
	@Column(name="available_seats")
	private int available_seats;
	
	@Column(name="departure_time")
	private String departure_time;
	
	@Column(name="arrival_time")
	private String arrival_time;
	
	@ManyToMany(mappedBy = "trips")
	private Set<User> users;
	
	public Trip() {
		super();
	}
	public void setId(int i) {
		id = i;
	}
	public int getId() {
		return id;
	}
	public void SetFromStation(String fs) {
		from_station= fs;
	}
	public String getFromStation() {
		return from_station;
	}
	public void SetavailableSeats(int as) {
		available_seats = as;
	}
	public int getAvailableSeats() {
		return available_seats;
	}
	public void SetToStation(String ts) {
		to_station= ts;
	}
	public String getToStation() {
		return to_station;
	}
	public void SetDepartureTime(String ds) {
		departure_time= ds;
	}
	public String getdeparturetime() {
		return departure_time;
	}
	public void SetArrivalTime(String at) {
		arrival_time = at;
	}
	public String getArrivalTime() {
		return arrival_time;
	}
	
	


}
