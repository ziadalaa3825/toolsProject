package EJBs;

import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2022-06-02T19:31:19.491+0200")
@StaticMetamodel(User.class)
public class User_ {
	public static volatile SingularAttribute<User, String> username;
	public static volatile SingularAttribute<User, String> password;
	public static volatile SingularAttribute<User, String> full_name;
	public static volatile SingularAttribute<User, String> role;
	public static volatile SingularAttribute<User, Integer> id;
	public static volatile SetAttribute<User, Notification> notifications;
	public static volatile SetAttribute<User, Trip> trips;
}
