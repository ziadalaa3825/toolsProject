package Service;

import javax.ws.rs.QueryParam;
import java.util.RandomAccess;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import javax.annotation.Resource;
import javax.ejb.EJBException;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.UserTransaction;
import javax.websocket.server.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces; 
import javax.ws.rs.core.MediaType;


import EJBs.Station;
import EJBs.Trip;
import EJBs.User;


@Stateless
@Path("/users")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class UserService {
	
	@PersistenceContext(unitName="hello")
	private EntityManager entitymanager;
	
	@Resource
	UserTransaction ut;
	
	
	Random r = new Random();

	static String UsingUUID(){
		UUID randomUUID = UUID.randomUUID();
		return randomUUID.toString().replaceAll("-","");
	}
	
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("user")
	public String register(User u) 
	{
		try {
			entitymanager.persist(u);
			return "sucess";
		}
		catch(Exception e)
		{
			throw new EJBException(e);
		}	
	}
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("login")
	public String login(User u) 
	{
		//User u1;
 
				String urname =  u.getName();
				String pass = u.getPassword();
			/*TypedQuery<User> query =  (TypedQuery<User>) entitymanager.createQuery("select username , password from user u where username = u.username and password = u.password",User.class);
			query.setParameter("username", username);
			query.setParameter("password", password);
			if(query.getResultList() != null )
			{
				return "login successfully";
			}
			else {
				return "login faiiled";
			}*/
				User u1 = entitymanager.createQuery("select u from User u where u.username = :username",User.class).setParameter("username", urname).getSingleResult();
				
				String anotherpass = u1.getPassword();
				String anotherusername = u1.getName();
				if(anotherusername.equals(urname) ) {
					if(anotherpass.equals(pass))
						return "login successfully";
				}
				else {
					return "login failed";
				}
				return ".";
		}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("trip")
	public String CreateTrip(Trip t) {
		try {
			entitymanager.persist(t);
			return "sucess";
		}
		catch(Exception e)
		{
			throw new EJBException(e);
		}	
	}
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("station")
	public String CreateStation(Station s) {
		try {
			entitymanager.persist(s);
			return "sucess";
		}
		catch(Exception e)
		{
			throw new EJBException(e);
		}	
	}
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("station/{id}")
	public Station GetStation(@PathParam("id") final int id) {
		try {
			return entitymanager.find(Station.class, id);
		}
		catch(Exception e)
		{
			throw new EJBException(e);
		}	
}
		@POST
		@Path("searchtrips")
        public List<Trip> searchTrips(Trip tb ){
                     		try
                     		{
                     			TypedQuery<Trip>query = entitymanager.createQuery("select t from Trip  t  where t.departure_time >= ?2 and t.arrival_time <= ?1 and t.from_station like ?3 and t.to_station like ?4  ",Trip.class);
                     			query.setParameter(2,  tb.getFrom_date());
                     			query.setParameter(1,  tb.getTo_date());
                     			query.setParameter(3,  tb.getFromStation());
                     			  
                     			query.setParameter(4,  tb.getToStation());
                     			List<Trip> trips = query.getResultList();
                     			return trips;
                     		
                     		}
                     		catch (Exception e) {
                     						throw new EJBException(e);
                               }
				}

}
			
				
				
				